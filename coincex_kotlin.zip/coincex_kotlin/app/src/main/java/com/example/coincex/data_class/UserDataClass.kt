package com.example.coincex.data_class

data class UserDataClass(
    val nome: String,
    val cognome: String,
    val telefono: String,
    val email: String,
    val username: String,
    val secretKey: String,
    val apikey: String
)