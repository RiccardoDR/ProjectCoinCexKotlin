package com.example.coincex.data_class

data class AssetAllocationDataClass(
    val color: Int,
    val symbol: String,
    val percent: Float
)